<?php wp_header(); ?>
<?php wp_footer(); ?>